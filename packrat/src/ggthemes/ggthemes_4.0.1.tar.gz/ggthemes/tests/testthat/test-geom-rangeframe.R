context("geom-rangeframe")

test_that("geom_rangeframe works", {
  expect_is(geom_rangeframe(), "LayerInstance")
})
