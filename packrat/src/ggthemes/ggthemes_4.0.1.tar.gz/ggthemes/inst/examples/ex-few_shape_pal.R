\dontrun{
  # need to set a font containing unicode values
  show_shapes(few_shape_pal()(5))
}
