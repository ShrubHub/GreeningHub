time.rwl <- function(x,...){
  as.numeric(rownames(x))
}

time.crn <- function(x,...){
  as.numeric(rownames(x))
}
