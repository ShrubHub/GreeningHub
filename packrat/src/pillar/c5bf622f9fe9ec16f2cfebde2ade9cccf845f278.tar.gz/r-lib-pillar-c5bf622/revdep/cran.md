## revdepcheck results

We checked 305 reverse dependencies (302 from CRAN + 3 from BioConductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 4 new problems
 * We failed to check 1 packages

Issues with CRAN packages are summarised below.

### New problems
(This reports the first line of each new failure)

* GSODR
  checking re-building of vignette outputs ... WARNING

* hms
  checking tests ...

* tibble
  checking tests ...

* unpivotr
  checking examples ... ERROR

### Failed to check

* cdcfluview (failed to install)
