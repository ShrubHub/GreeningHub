char * readBits(short);
int * getBits(int *, int *, int *);
int * getLandWater(int *, int *);
int * getCloudmask(int *, int *);
int * getDayNo(int *, int *);
