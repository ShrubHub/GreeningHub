int *dateToDoy(int *, int *);
int isLeap(int);
int getFullYear(int);
int *getDaysCount(int *, int *);
