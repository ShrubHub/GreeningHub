double *savGol(int *, double *, double *, int *, double *);
