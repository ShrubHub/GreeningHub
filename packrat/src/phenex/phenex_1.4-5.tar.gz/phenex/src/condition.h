double condition(double *, double *, int);
