double *sigmoid(int *, double *, double *, double *,double *);
double *sigmoidfct(double, double, double, double, int, double *);
double maximum(double *, int);
