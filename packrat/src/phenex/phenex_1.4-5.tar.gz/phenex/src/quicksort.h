void sort(double *, int *, int);
void quicksort(int, int, double *, int *);
int partition(int, int, double *, int *);
void swap(int, int, int *);
