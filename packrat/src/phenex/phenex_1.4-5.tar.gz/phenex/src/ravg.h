double *runAVG (int *, double *, int *, double *);
