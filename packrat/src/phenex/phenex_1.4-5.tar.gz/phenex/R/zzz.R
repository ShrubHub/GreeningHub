.onLoad <- function(libname, pkgname) {
	.initNDVI()
}
